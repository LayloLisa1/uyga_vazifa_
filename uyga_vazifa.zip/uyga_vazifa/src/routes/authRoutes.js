const express = require('express');
const router = express.Router();
const { signup, signin, verifyOtp } = require('../controllers/authController');
router.post('/signup', signup);
router.post('/signin', signin);
router.post('/otp/verify', verifyOtp);
module.exports = router;
