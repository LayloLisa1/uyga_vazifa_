const jwt = require('jsonwebtoken');
const Token = require('../models/Token');
const generateTokens = (userId) => {
  const accessToken = jwt.sign({ userId }, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '15m' });
  const refreshToken = jwt.sign({ userId }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: '7d' });
  return { accessToken, refreshToken };
};
const saveRefreshToken = async (userId, refreshToken) => {
  await Token.create({ userId, refreshToken });
};
module.exports = { generateTokens, saveRefreshToken };
