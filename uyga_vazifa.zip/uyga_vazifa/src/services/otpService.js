const crypto = require('crypto');
const Otp = require('../models/Otp');
const transporter = require('../config/mailer');
const generateOtp = () => {
  return crypto.randomBytes(3).toString('hex');
};
const sendOtp = async (email) => {
  const otp = generateOtp();
  const expiresAt = Date.now() + 10 * 60 * 1000; 
  await Otp.create({ email, otp, expiresAt });
  await transporter.sendMail({
    from: process.env.EMAIL,
    to: email,
    subject: 'Your OTP Code',
    text: `Your OTP code is ${otp}`,
  });
  return otp;
};
const verifyOtp = async (email, otp) => {
  const otpRecord = await Otp.findOne({ email, otp });
  if (!otpRecord || otpRecord.expiresAt < Date.now()) {
    return false;
  }
  await Otp.deleteOne({ email, otp });
  return true;
};
module.exports = { sendOtp, verifyOtp };
