const User = require('../models/User');
const Otp = require('../models/Otp');
const Token = require('../models/Token');
const { sendOtp, verifyOtp } = require('../services/otpService');
const { generateTokens, saveRefreshToken } = require('../services/tokenService');
exports.signup = async (req, res) => {
  const { email, password } = req.body;
  try {
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }
    user = new User({ email, password });
    await user.save();
    await sendOtp(email);
    res.status(201).json({ message: 'User registered, OTP sent to email' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};
exports.signin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password))) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }
    await sendOtp(email);
    res.status(200).json({ message: 'OTP sent to email' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};
exports.verifyOtp = async (req, res) => {
  const { email, otp } = req.body;
  try {
    const isValidOtp = await verifyOtp(email, otp);
    if (!isValidOtp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }
    const user = await User.findOne({ email });
    const { accessToken, refreshToken } = generateTokens(user._id);
    await saveRefreshToken(user._id, refreshToken);
    res.status(200).json({ accessToken, refreshToken });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};
